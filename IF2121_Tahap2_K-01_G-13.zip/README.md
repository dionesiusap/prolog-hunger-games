# Hunger Games Prolog

A simple adventure survival game in Prolog (GNU).
