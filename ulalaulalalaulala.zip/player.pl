/* baca file eksternal */
readPlayer :- 
        open('player.txt',read,F),
        rPlayer(F,Player),
        close(F),
        write(Player), nl.

rPlayer(F,[]) :- at_end_of_stream(F), !.

rPlayer(F,[X|L]) :- 
        \+ at_end_of_stream(F), !,
        read(F,X),
        rPlayer(F,L).

initPlayer :-
        open('Player.txt',write,F),
        rand(F),
        close(F).

rand(F) :-
        write(F,'\n'),
        random(1,21,N),
        write(F,N),
        write(F,'.\n'),
        random(1,11,M),
        write(F,M),
        write(F,'.\n'),
        write(F,'alive.\n').

writePlayer(Player) :-
        open('Player.txt',write,F),
		write(F,'\n'),
        list(Player),
        close(F).

list([]):-!.
list([H|T]) :-
        write(F,H),
        write(F,'.\n'),
		list(T).
		
